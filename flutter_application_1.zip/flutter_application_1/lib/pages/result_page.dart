import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart';

class ResultPage extends ConsumerStatefulWidget {
  const ResultPage({super.key});

  @override
  ConsumerState<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends ConsumerState<ResultPage> with TickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeAnimation, _scaleAnimation;
  Map<String, String> formData = {};

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(duration: const Duration(milliseconds: 800), vsync: this);
    _fadeAnimation = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1).animate(CurvedAnimation(parent: _controller, curve: Curves.elasticOut));
    _controller.forward();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final args = ModalRoute.of(context)?.settings.arguments;
    if (args is Map<String, String>) formData = args;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Hasil Pengiriman'),
        automaticallyImplyLeading: false,
        actions: [IconButton(icon: const Icon(Icons.close), onPressed: () => Navigator.popUntil(context, ModalRoute.withName('/')))],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [theme.colorScheme.surface, theme.colorScheme.primaryContainer.withOpacity(0.05)],
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: ScaleTransition(
                scale: _scaleAnimation,
                child: Column(
                  children: [
                    // Success header
                    Container(
                      width: 80, height: 80,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: Colors.green,
                        boxShadow: [BoxShadow(color: Colors.green.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 4))],
                      ),
                      child: const Icon(Icons.check_rounded, color: Colors.white, size: 40),
                    ),
                    const SizedBox(height: 24),
                    
                    Text('Berhasil Dikirim!', style: theme.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold, color: Colors.green.shade700)),
                    const SizedBox(height: 8),
                    Text('Formulir telah berhasil diproses', style: theme.textTheme.bodyLarge?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                    
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(color: theme.colorScheme.primaryContainer.withOpacity(0.3), borderRadius: BorderRadius.circular(20)),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.access_time, size: 16, color: theme.colorScheme.primary),
                          const SizedBox(width: 8),
                          Text('Dikirim pada ${_formatTime()}', 
                            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.primary, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 32),
                    
                    // Form data card
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(children: [
                              Icon(Icons.assignment_turned_in, color: theme.colorScheme.primary),
                              const SizedBox(width: 8),
                              Text('Detail Formulir', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
                            ]),
                            const SizedBox(height: 16),
                            ...formData.entries.map((e) => _buildDataItem(e.key, e.value, theme)),
                          ],
                        ),
                      ),
                    ),
                    
                    const SizedBox(height: 24),
                    
                    // Action buttons
                    SizedBox(
                      height: 50, width: double.infinity,
                      child: ElevatedButton(
                        onPressed: () => Navigator.popUntil(context, ModalRoute.withName('/')),
                        child: const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(Icons.home), SizedBox(width: 8), Text('Kembali ke Beranda')
                        ]),
                      ),
                    ),
                    
                    const SizedBox(height: 12),
                    Row(children: [
                      Expanded(child: OutlinedButton.icon(onPressed: _share, icon: const Icon(Icons.share), label: const Text('Bagikan'))),
                      const SizedBox(width: 12),
                      Expanded(child: OutlinedButton.icon(onPressed: _download, icon: const Icon(Icons.download), label: const Text('Unduh'))),
                    ]),
                    
                    const SizedBox(height: 24),
                    
                    // Additional info
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(children: [
                          Text('Informasi Tambahan', style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
                          const SizedBox(height: 8),
                          _buildInfoRow('ID Pengiriman:', _generateId(), theme),
                          _buildInfoRow('Status:', 'Berhasil Diproses', theme),
                          _buildInfoRow('Estimasi Respons:', '1-3 hari kerja', theme),
                        ]),
                      ),
                    ),
                    
                    const SizedBox(height: 32),
                    Text('© 2025 Raeldy - Enhanced Form App', style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildDataItem(String key, String value, ThemeData theme) {
    final labels = {'nama': 'Nama', 'nim': 'NIM', 'email': 'Email', 'telepon': 'Telepon', 'alamat': 'Alamat', 'pesan': 'Pesan'};
    final icons = {
      'nama': Icons.person, 'nim': Icons.badge, 'email': Icons.email, 
      'telepon': Icons.phone, 'alamat': Icons.home, 'pesan': Icons.message
    };
    
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(color: theme.colorScheme.primaryContainer.withOpacity(0.3), borderRadius: BorderRadius.circular(8)),
          child: Icon(icons[key] ?? Icons.info, color: theme.colorScheme.primary, size: 16),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(labels[key] ?? key, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
            Text(value.isEmpty ? '-' : value, style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
          ],
        )),
        IconButton(onPressed: () => _copy(value), icon: Icon(Icons.copy, size: 16, color: theme.colorScheme.primary)),
      ]),
    );
  }

  Widget _buildInfoRow(String label, String value, ThemeData theme) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(children: [
        Text(label, style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
        const SizedBox(width: 8),
        Text(value, style: theme.textTheme.bodySmall?.copyWith(fontWeight: FontWeight.w600)),
      ]),
    );
  }

  String _formatTime() {
    final now = DateTime.now();
    return '${now.day}/${now.month}/${now.year} ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
  }

  String _generateId() => 'FORM-${DateTime.now().millisecondsSinceEpoch.toString().substring(8)}';

  void _copy(String text) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Disalin: ${text.length > 20 ? '${text.substring(0, 20)}...' : text}')));
  }

  void _share() => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Fitur berbagi (simulasi)')));
  
  void _download() => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('PDF berhasil dibuat! (simulasi)')));

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}