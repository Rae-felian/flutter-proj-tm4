import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/form_providers.dart';

class WelcomePage extends ConsumerWidget {
  const WelcomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final analytics = ref.watch(analyticsProvider);
    
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aplikasi Formulir'),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () => _showInfo(context),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [theme.colorScheme.surface, theme.colorScheme.primaryContainer.withOpacity(0.1)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                const SizedBox(height: 40),
                Text('Selamat Datang!', style: theme.textTheme.headlineLarge?.copyWith(
                  color: theme.colorScheme.primary, fontWeight: FontWeight.bold)),
                const SizedBox(height: 12),
                Text('Aplikasi formulir dengan state management modern',
                  style: theme.textTheme.bodyLarge?.copyWith(color: theme.colorScheme.onSurfaceVariant),
                  textAlign: TextAlign.center),
                
                const SizedBox(height: 60),
                Container(
                  width: 150, height: 150,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: theme.colorScheme.primaryContainer.withOpacity(0.3),
                    border: Border.all(color: theme.colorScheme.primary.withOpacity(0.3), width: 2),
                  ),
                  child: Icon(Icons.assignment_outlined, size: 80, color: theme.colorScheme.primary),
                ),
                
                const SizedBox(height: 60),
                _buildFeatures(theme),
                const SizedBox(height: 40),
                
                SizedBox(
                  height: 56, width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      ref.track('started');
                      Navigator.pushNamed(context, '/form');
                    },
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [Icon(Icons.edit_outlined), SizedBox(width: 8), Text('Mulai Isi Formulir')],
                    ),
                  ),
                ),
                
                const SizedBox(height: 24),
                _buildAnalytics(analytics, theme),
                const Spacer(),
                Text('© 2025 Raeldy', style: theme.textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFeatures(ThemeData theme) {
    final features = [
      (Icons.speed, 'State Management dengan Riverpod'),
      (Icons.palette_outlined, 'Material 3 Design System'),
      (Icons.security, 'Form Validation yang Advanced'),
    ];
    
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Fitur Aplikasi', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            ...features.map((f) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(children: [
                Icon(f.$1, color: theme.colorScheme.primary, size: 20),
                const SizedBox(width: 12),
                Text(f.$2, style: theme.textTheme.bodyMedium),
              ]),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildAnalytics(Map<String, int> analytics, ThemeData theme) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildStat('Dimulai', analytics['started'] ?? 0, Icons.play_arrow, theme),
            _buildStat('Selesai', analytics['completed'] ?? 0, Icons.check_circle, theme),
            _buildStat('Error', analytics['errors'] ?? 0, Icons.error, theme),
          ],
        ),
      ),
    );
  }

  Widget _buildStat(String label, int count, IconData icon, ThemeData theme) {
    return Column(children: [
      Icon(icon, color: theme.colorScheme.primary),
      Text('$count', style: theme.textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
      Text(label, style: theme.textTheme.bodySmall),
    ]);
  }

  void _showInfo(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Tentang Aplikasi'),
        content: const Text('Fitur yang diimplementasikan:\n• State Management dengan Riverpod\n• Material 3 Design System\n• Form Validation yang Advanced\n• Loading States dan Animasi\n• Analytics Tracking'),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Tutup'))],
      ),
    );
  }
}