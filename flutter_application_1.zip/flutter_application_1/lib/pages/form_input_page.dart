import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/services.dart';
import '../providers/form_providers.dart';

class FormInputPage extends ConsumerStatefulWidget {
  const FormInputPage({super.key});

  @override
  ConsumerState<FormInputPage> createState() => _FormInputPageState();
}

class _FormInputPageState extends ConsumerState<FormInputPage> {
  final _formKey = GlobalKey<FormState>();
  final _controllers = <String, TextEditingController>{
    'nama': TextEditingController(),
    'nim': TextEditingController(),
    'email': TextEditingController(),
    'telepon': TextEditingController(),
    'alamat': TextEditingController(),
    'pesan': TextEditingController(),
  };

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final formState = ref.watch(formProvider);
    final passwordVisible = ref.watch(passwordVisibleProvider);
    
    return Scaffold(
      appBar: AppBar(title: const Text('Formulir Input')),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [theme.colorScheme.surface, theme.colorScheme.primaryContainer.withOpacity(0.05)],
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('Informasi Pribadi', style: theme.textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                Text('Silakan lengkapi semua informasi dengan benar', style: theme.textTheme.bodyLarge?.copyWith(color: theme.colorScheme.onSurfaceVariant)),
                const SizedBox(height: 32),
                
                _buildField('nama', 'Nama Lengkap', Icons.person_outline, 
                  validator: (v) => v?.isEmpty ?? true ? 'Nama tidak boleh kosong' : v!.length < 2 ? 'Minimal 2 karakter' : null),
                
                _buildField('nim', 'NIM', Icons.badge_outlined, 
                  type: TextInputType.number, formatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (v) => v?.isEmpty ?? true ? 'NIM tidak boleh kosong' : v!.length < 8 ? 'Minimal 8 digit' : null),
                
                _buildField('email', 'Email', Icons.email_outlined, type: TextInputType.emailAddress,
                  validator: (v) => v?.isEmpty ?? true ? 'Email tidak boleh kosong' : !v!.contains('@') ? 'Email tidak valid' : null),
                
                _buildField('telepon', 'Nomor Telepon', Icons.phone_outlined, 
                  type: TextInputType.phone, formatters: [FilteringTextInputFormatter.digitsOnly],
                  validator: (v) => v?.isEmpty ?? true ? 'Nomor telepon tidak boleh kosong' : v!.length < 10 ? 'Minimal 10 digit' : null),
                
                _buildField('alamat', 'Alamat', Icons.home_outlined, maxLines: 3,
                  validator: (v) => v?.isEmpty ?? true ? 'Alamat tidak boleh kosong' : v!.length < 10 ? 'Alamat terlalu pendek' : null),
                
                _buildField('pesan', 'Pesan', Icons.message_outlined, maxLines: 4, required: false),
                
                // Password demo with visibility toggle
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Password (Demo)', prefixIcon: const Icon(Icons.lock_outline),
                    suffixIcon: IconButton(
                      icon: Icon(passwordVisible ? Icons.visibility_off : Icons.visibility),
                      onPressed: () => ref.read(passwordVisibleProvider.notifier).state = !passwordVisible,
                    ),
                  ),
                  obscureText: !passwordVisible,
                  validator: (v) => v != null && v.isNotEmpty && v.length < 6 ? 'Minimal 6 karakter' : null,
                ),
                
                const SizedBox(height: 40),
                SizedBox(
                  height: 56,
                  child: ElevatedButton(
                    onPressed: formState.status == FormStatus.loading ? null : _submit,
                    child: formState.status == FormStatus.loading
                        ? const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)),
                            SizedBox(width: 12), Text('Mengirim...')
                          ])
                        : const Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Icon(Icons.send), SizedBox(width: 8), Text('Kirim Formulir')
                          ]),
                  ),
                ),
                
                const SizedBox(height: 16),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    TextButton.icon(onPressed: () => _formKey.currentState?.reset(), 
                      icon: const Icon(Icons.refresh), label: const Text('Reset')),
                    TextButton.icon(onPressed: _saveDraft, 
                      icon: const Icon(Icons.save), label: const Text('Simpan')),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildField(String key, String label, IconData icon, {
    TextInputType? type, List<TextInputFormatter>? formatters, int maxLines = 1,
    String? Function(String?)? validator, bool required = true
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 20),
      child: TextFormField(
        controller: _controllers[key],
        decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon)),
        keyboardType: type, inputFormatters: formatters, maxLines: maxLines,
        validator: required ? validator : (v) => v != null && v.isNotEmpty ? validator?.call(v) : null,
      ),
    );
  }

  void _submit() async {
    if (_formKey.currentState?.validate() ?? false) {
      final data = FormData(
        nama: _controllers['nama']!.text, 
        nim: _controllers['nim']!.text, 
        email: _controllers['email']!.text, 
        telepon: _controllers['telepon']!.text, 
        alamat: _controllers['alamat']!.text, 
        pesan: _controllers['pesan']!.text,
      );
      
      await ref.read(formProvider.notifier).submitForm(data);
      
      final state = ref.read(formProvider);
      if (mounted) {
        if (state.status == FormStatus.success) {
          ref.track('completed');
          Navigator.pushNamed(context, '/result', arguments: state.data!.toMap());
        } else if (state.status == FormStatus.error) {
          ref.track('errors');
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(state.error ?? 'Terjadi kesalahan'), backgroundColor: Colors.red),
          );
        }
      }
    }
  }

  void _saveDraft() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Draft disimpan (simulasi)')));
  }

  @override
  void dispose() {
    _controllers.values.forEach((c) => c.dispose());
    super.dispose();
  }
}