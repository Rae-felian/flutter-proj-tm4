import 'package:flutter_riverpod/flutter_riverpod.dart';

class FormData {
  final String nama, nim, email, telepon, alamat, pesan;
  
  const FormData({
    required this.nama, required this.nim, required this.email,
    required this.telepon, required this.alamat, required this.pesan,
  });
  
  Map<String, String> toMap() => {
    'nama': nama, 'nim': nim, 'email': email,
    'telepon': telepon, 'alamat': alamat, 'pesan': pesan,
  };
}

enum FormStatus { initial, loading, success, error }

class FormSubmissionState {
  final FormStatus status;
  final String? error;
  final FormData? data;
  
  const FormSubmissionState({this.status = FormStatus.initial, this.error, this.data});
  
  FormSubmissionState copyWith({FormStatus? status, String? error, FormData? data}) =>
      FormSubmissionState(status: status ?? this.status, error: error, data: data ?? this.data);
}

class FormNotifier extends StateNotifier<FormSubmissionState> {
  FormNotifier() : super(const FormSubmissionState());
  
  Future<void> submitForm(FormData data) async {
    state = state.copyWith(status: FormStatus.loading);
    await Future.delayed(const Duration(seconds: 2));
    
    if (DateTime.now().millisecondsSinceEpoch % 20 == 0) {
      state = state.copyWith(status: FormStatus.error, error: 'Gagal mengirim formulir');
    } else {
      state = state.copyWith(status: FormStatus.success, data: data);
    }
  }
  
  void reset() => state = const FormSubmissionState();
}

final formProvider = StateNotifierProvider<FormNotifier, FormSubmissionState>((ref) => FormNotifier());
final passwordVisibleProvider = StateProvider<bool>((ref) => false);
final analyticsProvider = StateProvider<Map<String, int>>((ref) => {'started': 0, 'completed': 0, 'errors': 0});

extension Analytics on WidgetRef {
  void track(String key) {
    final current = read(analyticsProvider);
    read(analyticsProvider.notifier).state = {...current, key: (current[key] ?? 0) + 1};
  }
}